<?php
    // pripojeni souboru s funkcemi

?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Výstup</title>
    </head>
    <body>
        <h1>Výstup formuláře</h1>
    
        <div>
            <strong>Post:</strong> <br>
            <?php
                // zpracovani prijatych dat + vypis pole do tabulky

            ?>
        </div>
        <br>
        
        <div>
            <strong>Get:</strong> <br>
            <?php
                // zpracovani prijatych dat + vypis pole do tabulky

            ?>
        </div>
        
    </body>
</html>