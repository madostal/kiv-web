
# form.php
- doplňte select výpisem hodnot ze souboru zvirata.txt

# vystup.php
- doplňte výpis hodnot z formuláře do tabulky, pokud není hodnota vypište “nezadáno”.

# nový soubor
- vytvořte nový php soubor, přesuňte do něj funkce z vystup.php a zakomponujte soubor do vystup.php
- doplňte fci pro uložení tabulky do souboru s názvem “rok-mesic-den_hodina-minuty.txt” v adresáři “vystup”
-- pom - date("Y-m-d_H-i")


# další úkol
- vytvořte tři funkce a, c, n, které vypíší odlišné pozdravy
- doplňte formulář o SELECT se jménem “pozdrav” s volbami a, c, n.
- po odeslání formuláře zavolejte funkci, jejíž jméno je uloženo v odeslaném poli pod klíčem “pozdrav”

- zkuste si vytvořit a vypsat multi-typové pole

