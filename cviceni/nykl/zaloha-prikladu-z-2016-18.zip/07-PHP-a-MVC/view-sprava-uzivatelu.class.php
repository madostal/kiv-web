<?php

class ViewSpravaUzivatelu {
    
    public function __construct() {
        
    }

    /**
     *  Obali data vzhledem stranky a vrati vysledne HTML.
     *  @param array $data Data pro zobrazeni. 
     *  @return string Vysledny vzhled stranky.
     */
    public function getTemplate($data){
        
    }
    
}

?>