<?php 
// vstupni bod webove aplikace


?>