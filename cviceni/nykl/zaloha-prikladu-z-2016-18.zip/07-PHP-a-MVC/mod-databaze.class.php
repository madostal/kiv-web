<?php

class ModDatabaze {
    
    public function __construct() {
        
    }

    /**
     *  Vrati seznam vsech pohadek pro uvodni stranku.
     *  @return array Obsah uvodu.
     */
    public function getAllIntroductions(){
        
    }
    
    
    /**
     *  Vrati seznam vsech uzivatelu pro spravu uzivatelu.
     *  @return array Obsah spravy uzivatelu.
     */
    public function getAllUsers(){
        
    }
    
    /**
     *  Smaze daneho uzivatele z DB.
     *  @param integer $userId  ID uzivatele
     */
    public function deleteUser($userId){
        
    }
    
}

?>