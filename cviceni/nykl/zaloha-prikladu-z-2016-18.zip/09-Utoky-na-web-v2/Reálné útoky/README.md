# Ukázka útoků, které se dostaly na mé weby

* Hlavním cílem ukázky je spíše ukázat, jak také může vypadat PHP kód.
* Útoky 01 a 02 - nevím, jak se mi tyto kódy dostaly na web (zvláště zajímavé to bylo v případě 01, kdy web neobsahuje vůbec žádné vstupy uživatele a pouze vypisuje statický obsah).
* Útok 02 - ukázkový soubor index.php je souborem spouštějícím Drupal.


## Bonusové body ke zkoušce

* Ten, kdo první získá alespoň čitelný kód útoku 02 a ideálně se pokusí určit, co daný kód dělá, získá **5 bodů** k samostatné práci.
