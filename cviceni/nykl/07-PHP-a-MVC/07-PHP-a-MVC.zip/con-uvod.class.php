<?php

class ConUvod {
    
    public function __construct() {
        
    }

    /**
     *  Vrati obsah stranky
     *  @return string Obsah stranky
     */
    public function getResult(){
        
    }
    
}

?>