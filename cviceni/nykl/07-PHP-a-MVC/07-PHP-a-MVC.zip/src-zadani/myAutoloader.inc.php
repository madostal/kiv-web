<?php

//// automaticka registrace pozadovanych trid
spl_autoload_register(function ($className){

    // TODO - doplnte kod pro nacteni souboru s pozadovanou tridou

});



?>
