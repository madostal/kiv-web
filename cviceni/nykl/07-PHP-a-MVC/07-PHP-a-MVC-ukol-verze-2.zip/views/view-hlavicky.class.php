<?php

/**
 * Trida vypisujici HTML hlavicky stranky
 */
class ViewHlavicky {

    /**
     *  Vrati vrsek stranky az po oblast, 
     *  ve ktere se vypisuje obsah stranky.
     *  @param string $title Nazev stranky.
     */
    public function getHTMLHeader($title){
        ?>

        <!doctype html>
        <html>
            <head>
                <meta charset='utf-8'>
                <title><?php echo $title; ?></title>
            </head>
            <body>
                <h1>Template: <?php echo $title; ?></h1>

        <?php

        // TODO - zde by melo byt vypsano napr. i menu.

    }
    
    /**
     *  Vrati paticku stranky.
     */
    public function getHTMLFooter(){
        ?>

            <body>
        </html>

        <?php
    }
        
}

?>