<?php
/////////// Sablona pro zobrazeni uvodu  ///////////

// TODO - urceni globalnich promennych, se kterymi sablona pracuje

// sablona je samostatna a provadi primy vypis do vystupu
// -> lze testovat bez zbytku aplikace
// -> pri vyuziti Twigu se sablona obejde bez PHP

// pripojim objekt pro vypis hlavicky a paticky HTML
require("view-hlavicky.class.php");
$hlavicky = new ViewHlavicky();

// Uvod bude vypisovat informace z tabulky, ktera ma nasledujici sloupce:
// id, date, author, title, text
$tmp = [
  array("id" => 1, "date" => "2016-11-01 10:53:00", "author" => "A.B.", "title" => "Nadpis", "text" => "abcd")
];

?>

<!-- obsah sablony -->
