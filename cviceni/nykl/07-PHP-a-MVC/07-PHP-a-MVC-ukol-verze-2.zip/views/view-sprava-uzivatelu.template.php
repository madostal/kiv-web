<?php
/////////// Sablona pro spravy uzivatelu  ///////////

// TODO - urceni globalnich promennych, se kterymi sablona pracuje

// sablona je samostatna a provadi primy vypis do vystupu
// -> lze testovat bez zbytku aplikace
// -> pri vyuziti Twigu se sablona obejde bez PHP

// pripojim objekt pro vypis hlavicky a paticky HTML
require("view-hlavicky.class.php");
$hlavicky = new ViewHlavicky();

?>

<!-- obsah sablony -->
