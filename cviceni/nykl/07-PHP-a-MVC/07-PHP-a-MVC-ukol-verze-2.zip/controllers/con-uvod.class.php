<?php

class ConUvod {
    
    public function __construct() {
        // TODO - inicializace prace s DB
    }

    /**
     *  Vrati obsah stranky
     *  @return string Obsah stranky
     */
    public function getResult(){
        // TODO - nastaveni globalnich promennych pro sablonu

        // TODO - naplneni globalnich promennych

        //// vypsani prislusne sablony
        // zapnu output buffer pro odchyceni vypisu sablony
        ob_start();
        // pripojim sablonu, cimz ji i vykonam
        require "view-uvod.template.php";
        // ziskam obsah output bufferu, tj. vypsanou sablonu
        $obsah = ob_get_clean();

        // vratim sablonu naplnenou daty
        return $obsah;
    }
    
}

?>