<?php 
/////////// Vstupni bod webove aplikace /////////////

// vynuceni chybovych vypisu na students.kiv.zcu.cz
// ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);

// nactu nastaveni
require_once("settings.inc.php");

// TODO - test, zda je v pozadavku uvedena pozadovana stranka, jinak defaultni

// TODO - nacteni odpovidajiciho kontroleru, jeho zavolani a vypsani vysledku


?>