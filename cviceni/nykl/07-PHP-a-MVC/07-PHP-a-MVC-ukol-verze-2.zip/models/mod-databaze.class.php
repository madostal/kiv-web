<?php

class ModDatabaze {

    /** @var PDO $pdo Objekt pracujici s databazi prostrednictvim PDO */
    private $pdo;
    
    public function __construct() {
        // nactu nastaveni
        require_once("settings.inc.php");
        // inicializace DB
        $this->pdo = new PDO("mysql:host=".DB_SERVER.";dbname=".DB_NAME, DB_USER, DB_PASS);
    }

    /**
     *  Vrati seznam vsech pohadek pro uvodni stranku.
     *  @return array Obsah uvodu.
     */
    public function getAllIntroductions(){
        
    }
    
    
    /**
     *  Vrati seznam vsech uzivatelu pro spravu uzivatelu.
     *  @return array Obsah spravy uzivatelu.
     */
    public function getAllUsers(){
        
    }
    
    /**
     *  Smaze daneho uzivatele z DB.
     *  @param integer $userId  ID uzivatele.
     */
    public function deleteUser($userId){
        
    }
    
}

?>