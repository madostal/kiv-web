<?php
/////////////////  Nastaveni aplikace ///////////////////

//// Prace s databazi
// pripojeni k DB
define("DB_SERVER", "");
define("DB_NAME", "");
define("DB_USER", "");
define("DB_PASS", "");

// nazvy tabulek v DB
define("TAB_INTRODUCTION", "nyklm_mvc_introductions");
define("TAB_USERS", "nyklm_mvc_users");


//// Dostupne stranky webu a jejich prechody
// adresar kontroleru
const CONTROLLERS_DIRECTORY = "controllers";
// defaultni webu
const DEFAULT_PAGE = "uvod";
// dostupne stranky
const PAGES = array(
    "uvod" => array("file" => "con-uvod.class.php", "object" => "ConUvod", "title" => "Úvod")
    // TODO - doplnit spravu uzivatelu
);

?>