<?php

/**
 * Interface IDrawable
 * Rozhrani pro "vykreslitelnost".
 */
interface IDrawable {

    /**
     * Vykresli dany tvar.
     */
    public function draw();

}

?>
