<?php
// Soubor pro vytvareni utocnych kodu.
?>
- XSS budeme provádět skrze návštěvní knihu.
- SQL Injection budeme provádět skrze zobrazení příspěvku.
