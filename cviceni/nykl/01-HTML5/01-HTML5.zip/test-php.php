<?php 

echo "!! Hello word !!<br><br>";

$pole = array("Z", "C", "U", "-", "K","I","V");

foreach($pole as $p){
    echo $p."_";
}

?>